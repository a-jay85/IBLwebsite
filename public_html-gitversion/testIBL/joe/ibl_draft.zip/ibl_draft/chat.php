<?
include "includes/classes.inc.php";
$page = new page("chat");
echo $page->draw();
?>