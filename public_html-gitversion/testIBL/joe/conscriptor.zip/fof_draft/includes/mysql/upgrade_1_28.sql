ALTER TABLE `team` ADD `team_email_prefs` TINYINT NOT NULL DEFAULT '1';
