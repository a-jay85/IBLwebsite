ALTER TABLE `pick` ADD `pick_start` DATETIME NULL ;
ALTER TABLE `pick` ADD `pick_expired` INT( 1 ) NULL ;
