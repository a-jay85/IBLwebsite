ALTER TABLE `mock_draft` ADD `mock_draft_commentary` TEXT NULL ;
